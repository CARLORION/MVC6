﻿using System;
using Microsoft.AspNet.Mvc;

namespace TesteVS2015MVC.Compiler.Preprocess
{
    public class RazorPreCompilation : RazorPreCompileModule
    {
        public RazorPreCompilation(IServiceProvider provider) : base(provider)
        {
        }
    }
}
